# main class of the module

def main():
    pass


if __name__ == '__main__':
    main()
